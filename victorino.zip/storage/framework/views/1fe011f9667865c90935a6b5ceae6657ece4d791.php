<?php if(session('background')): ?>
    <script>
        window.alert("<?php echo e(session('backgorund')); ?>");
    </script>
<?php endif; ?>

<?php if(session('update')): ?>
    <script>
        window.alert("<?php echo e(session('update')); ?>");
    </script>
<?php endif; ?>

<?php if(session('erroUpdate')): ?>
    <script>
        window.alert("<?php echo e(session('erroUpdate')); ?>");
    </script>
<?php endif; ?>


<?php $__env->startSection('form'); ?>

    <div class="container">

        <div class="row my-4">
            <h2><strong>Background</strong></h2>
        </div>
        
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <form action="<?php echo e(route('image.update', ['image' => $image->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="background" value="1">

                        <div class="row w-100 mb-4">
                            <div class="col">
                                <img src="/storage/<?php echo e($image->path); ?>" style="width: 400px; height: 170;"> <br>
                                <strong>Alterar >>></strong> <input type="file" name="img">
                            </div>
                            <div class="col d-flex align-items-center">
                                <input type="submit" value="SALVAR">
                            </div>
                        </div>
                            
                </form>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('images.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/background/edit.blade.php ENDPATH**/ ?>