<?php if(session('update')): ?>
    <script>
        window.alert("<?php echo e(session('update')); ?>");
    </script>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <!-- CARD -->
    <div class="card  mx-auto text-center">
        <!-- CARD HEADER -->
        <div class="card-header" style="font-size: 20px">
            <ul class="nav nav-tabs card-header-tabs">

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('user.list')); ?>">Usuários</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('user.create')); ?>" tabindex="-1" aria-disabled="true"><i class="fas fa-user-plus"></i></a>
                </li>

            </ul>
        </div>
        <!-- END OF CARD HEADER -->

        <!--CARD BODY -->
        <div class="card-body my-4" style="font-size: 15px">
            
                <h4 class="mb-4">CADASTRO DE USUÁRIO</h4>

                <form action="<?php echo e(route('user.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">Nome</label>

                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right">E-mail</label>

                        <div class="col-md-6">
                            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right">Senha</label>

                        <div class="col-md-6">
                            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirmar senha</label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>
                    
                    <div class="row">
                        <label for="type" class="col-md-4 text-md-right">Admin</label>

                        <input type="checkbox" id="type" name="type" value="1" style="width: 20px; height: 20px;">

                        <small class="form-text text-muted ml-1">
                            Permitir que o usuário cadastre e exclua outros usuários.
                        </small>

                    </div>

                    <div class="form-group row mt-4 mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                Cadastrar
                            </button>
                        </div>
                    </div>

                </form>
            
        </div>
        <!-- END CARD BODY -->

    </div>
    <!-- END CARD -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/users/create.blade.php ENDPATH**/ ?>