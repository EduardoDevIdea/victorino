<?php echo e($slot); ?>

<?php /**PATH C:\Meus Projetos\victorino\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>