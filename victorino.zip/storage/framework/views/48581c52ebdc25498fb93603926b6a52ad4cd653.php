<?php $__env->startSection('form'); ?>

    <div class="container">

        <div class="row my-4">
            <h2>Logomarca</h2>
        </div>
        
        <img src="/storage/<?php echo e($image->path); ?>" style="width: 450px; height:150px;"> <br><br>
        <a href="<?php echo e(route('image.edit', ['image' => $image->id])); ?>" class="btn btn-warning">
            Editar
        </a>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('images.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/logo/list.blade.php ENDPATH**/ ?>