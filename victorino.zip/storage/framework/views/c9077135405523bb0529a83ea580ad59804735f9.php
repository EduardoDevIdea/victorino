<?php $__env->startSection('form'); ?>

    <div class="card pt-4" style="width: 500px;">

            <img src="/storage/<?php echo e($image->path); ?>" class="mx-auto" style="width: 450px; height: 150px;">

            <div class="card-header">
                <strong>Alterar Logomarca</strong> 
            </div>

            <div class="card-body">
                <form action="<?php echo e(route('image.update', ['image' => $image->id ])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden"  name="logo" value="1">
                    
                    <p class="card-text">
                        <input type="file" name="img">
                    </p>

                    <input type="submit" value="Salvar" class="btn btn-primary">
                    
                    <a href="#">Voltar</a>
                </form>
            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('images.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/logo/edit.blade.php ENDPATH**/ ?>