<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script src="https://kit.fontawesome.com/385c7d7d19.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
</head>
<style>
   
    .load {
        background: #231F20;
        z-index: 1;
        position: absolute;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .lost {
        display: none;
    }
    .spin {
        border: 8px solid transparent;
        border-left:8px solid orange;
        height: 60px;
        width: 60px;
        border-radius: 60px; 
        animation: spin 1s linear infinite;
    }
  

    @keyframes  spin {
        to {
            transform :rotate(360deg)
        }
    }
</style>

<?php echo $__env->yieldContent('content'); ?>

  <section id="footer">
                    <div class="container">
                        <div class="footer_information text-center">
                            <div class="row">
                                <div class="col-sm-6  col-xs-12 text-center">
                                    <img src="<?php echo e(asset('images/Screenshot_2.png')); ?>" alt="" width="80%">    
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <p>Menu</p>
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item">
                                            <a class="nav-link item-menu" href="#sobre">Sobre Nós</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link item-menu" href="#especialidade">Especialidades</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link item-menu" href="#espaco">O Espaço</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link item-menu" href="#profissionais">Profissionais</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link item-menu" href="#contato">Contato</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link item-menu" href="#Blog">Blog</a>
                                        </li>
                                    </div>    
                                    <a class="nav-link item-menu" href="#banner"><i class="fas fa-arrow-up" style="color: white; cursor:pointer"></i></a>
                                
                            </div>
                        </div>
                        <hr style="background:white">
                        <div class="row">
                            
                            <div class="col-sm-6 col-xr-12">
                                <p style="color: white">© Copyright 2020 - <?php echo date('Y') ?> Victoriano Odontologia Especializada </p>
                            </div>
                            <div class="col-sm-6 col-xr-12 text-center">
                                <p style="color: white">Desenvolvido por </p>
                            </div>
                        </div>
                    </div>
                </section>
</html><?php /**PATH C:\Meus Projetos\victorino\resources\views/layouts/base1.blade.php ENDPATH**/ ?>