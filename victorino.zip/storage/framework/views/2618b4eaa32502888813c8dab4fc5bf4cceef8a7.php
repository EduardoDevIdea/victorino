<?php $__env->startSection('content'); ?>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

    <?php if(session('store')): ?>
        <script>
            Swal.fire({
            icon: 'success',
            title: "<?php echo e(session('store')); ?>",
            showConfirmButton: false,
            })
        </script>
    <?php endif; ?>

    <?php if(session('update')): ?>
      <script>
          Swal.fire({
            icon: 'success',
            title: "<?php echo e(session('update')); ?>",
            showConfirmButton: false,
            })
      </script>
    <?php endif; ?>

    <?php if(session('erroImg')): ?>
      <script>
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: "<?php echo e(session('erroImg')); ?>",
            })
      </script>
    <?php endif; ?>

    <?php if(session('delete')): ?>
      <script>
          Swal.fire(
            'Deletado!',
            "<?php echo e(session('delete')); ?>",
            'success'
            )
         window.alert("<?php echo e(session('delete')); ?>");
      </script>
    <?php endif; ?>      
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h2 class="page-title">Profissionais</h2>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">Profissionais</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- CARD -->
    <div class="card text-center">

        <!-- CARD HEADER-->
        <div class="card-header" style="font-size: 20px">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('profissional.index')); ?>" title="Listar profissionais">Listar</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('profissional.create')); ?>" title="Cadastrar profissional">Cadastrar</a>
                </li>      
            </ul>
        </div>
        <!-- END CARD HEADER-->

        <!-- CARD BODY -->
        <div class="card-body m-4" style="font-size: 15px">
            
            <h3 class="mb-3"><strong>Profissionais cadastrados</strong></h3>

            <table class="table w-75 mx-auto">

                <thead class="thead-dark">
                    <tr>
                        <th>Nome</th>
                        <th>Cargo</th>
                        <th>Atividade</th>
                        <th>Ações</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $profissionais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profissional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td><?php echo e($profissional->nome); ?></td>

                            <td><?php echo e($profissional->cargo); ?></td>
                            
                            <td><?php echo e($profissional->atividade); ?></td>

                            <td>
                                <button class="btn btn-link" data-toggle="tooltip" data-placement="bottom"  title="Editar">
                                    <a href="<?php echo e(route('profissional.edit', ['profissional' => $profissional->id])); ?>"><i class="fas fa-edit" style="color: black"></i></a>
                                </button>

                                <button class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Excluir">
                                    <a  onclick="apagar(<?php echo e($profissional->id); ?>)" >
                                        <i class="fas fa-trash-alt" style="color: red"></i> <!-- icone -->
                                    </a>
                                </button>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

            <!-- Paginate -->
            <div class="container">
            <?php echo e($profissionais->links()); ?>

            </div>

        </div>
        <!-- END CARD BODY -->

    </div>
    <!-- END CARD -->

    <script>
        function apagar(id) {
            Swal.fire({
                title: "Deletar Profissional ?!",
                text: "Você não poderá reverter essa ação!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                cancelButtonText: "Cancelar",
                confirmButtonText: "Deletar"
            }).then(async (result) => {
                if (result.value) {
                    var url = "<?php echo e(url('/profissional')); ?>"
                    var  response = await fetch(url + `/${id}/delete`)
                    window.location.reload()
                    
                }
            })
           
        }
    </script>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/profissionais/index.blade.php ENDPATH**/ ?>