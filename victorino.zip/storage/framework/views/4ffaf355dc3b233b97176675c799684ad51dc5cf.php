<?php if(session('update')): ?>
    <script>
        window.alert("<?php echo e(session('update')); ?>");
    </script>
<?php endif; ?>

<?php if(session('store')): ?>
    <script>
        window.alert("<?php echo e(session('store')); ?>");
    </script>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <!-- CARD -->
    <div class="card text-center">

        <!-- CARD HEADER -->
        <div class="card-header" style="font-size: 20px">
            <ul class="nav nav-tabs card-header-tabs">
            
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('user.list')); ?>" title="Listar usuários">Usuários</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('user.create')); ?>" tabindex="-1" aria-disabled="true" title="Cadastrar usuário">
                        <i class="fas fa-user-plus"></i>
                    </a>
                </li>
                
            </ul>
        </div>
        <!-- END CARD HEADER -->

        <!-- CARD BODY -->
        <div class="card-body m-4" style="font-size: 15px">
            
            <h4 class="mb-4">USUÁRIOS CADASTRADOS</h4>

            <table class="table w-75 mx-auto">

                <thead class="thead-dark">
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Ações</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>

                             <!-- Se o registro é o do user que está autenticado, não aparece opções para editar e excluir -->
                            <?php if($user->id == Auth::id()): ?>
                                <td>
                                    <a href="<?php echo e(route('user.index')); ?>">
                                        <i class="fas fa-user fa-lg" title="Meu perfil"></i> <!-- icone direciona para o seu perfil -->
                                    </a>
                                </td>
                                
                             <!-- Se user for master, nao pode ser editado, nem excluido -->    
                            <?php elseif($user->type == "master"): ?> 
                                <td>
                                    <a href="#">
                                        <i class="fas fa-user-shield fa-lg" style="color:black" title="Master"></i> <!-- icone -->
                                    </a>
                                </td>
                                    <!-- Manter o <td> vazio para formataçao da tabela -->
                                <td>
                            <?php else: ?>
                                <td>
                                    <a href="<?php echo e(route('user.edit', ['user' => $user->id])); ?>" class="mr-3" title="Editar">
                                        <i class="fas fa-edit" style="color: black"></i> <!-- icone -->
                                    </a>
                               
                                    <a href="<?php echo e(route('user.destroy', ['user' => $user->id])); ?>" onclick="return confirm('Tem certeza que deseja excluir o registro?');" title="Excluir">
                                        <i class="fas fa-trash-alt" style="color: red"></i> <!-- icone -->
                                    </a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>

            <!-- Paginação -->
            <div class="container w-75">
                <div class="row">
                    <?php echo e($users->links()); ?>

                </div>  
            </div>

        </div>
        <!-- END CARD BODY -->

    </div>
    <!-- END CARD -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/users/list.blade.php ENDPATH**/ ?>