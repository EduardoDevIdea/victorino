<?php $__env->startSection('cpontent'); ?>
    Olá
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/dashboard.blade.php ENDPATH**/ ?>