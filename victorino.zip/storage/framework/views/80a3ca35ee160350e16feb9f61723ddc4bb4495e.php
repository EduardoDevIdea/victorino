<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Especialidades</h2>
            <div class="ml-auto text-right">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item " aria-current="page">Especialidades</li>
                        <li class="breadcrumb-item active" aria-current="page">Editar</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
   <!-- CARD -->
    <div class="card text-center">

        <!-- CARD HEADER-->
        <div class="card-header" style="font-size: 20px">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('especialidade.index')); ?>">Especialidades</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="<?php echo e(route('especialidade.create')); ?>">Cadastrar</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#"><i class="far fa-edit"></i></a>
                </li>     
            </ul>
        </div>
        <!-- END CARD HEADER-->

        <!-- CARD BODY -->
        <div class="card-body" style="font-size: 15px">

            <form action="<?php echo e(route('especialidade.update', ['especialidade' => $especialidade->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                    
                <h3 class="card-title"><strong>Editar Especialidade</strong></h3>
                
                <div class="form-group row mt-3">
                    <label for="nome" class="col-sm-3 text-right control-label col-form-label"><strong>Nome da especialidade</strong></label>
                    <div class="col-sm-9">
                        <input type="text" name="nome" value="<?php echo e($especialidade->nome); ?>" class="form-control" id="fname" required autofocus>
                    </div>
                </div>
                    
                <div class="form-group row">
                    <label for="cono1" class="col-sm-3 text-right control-label col-form-label"><strong>Descrição</strong></label>
                    <div class="col-sm-9">                                  
                        <textarea id="description" name="description" class="form-control" cols="70" rows="10"><?php echo e($especialidade->description); ?></textarea>
                    </div>
                </div>

                <div class="border-top">
                    <div class="card-body">
                        <input type="submit" value="Salvar" class="btn btn-primary">
                    </div>
                </div>
                
            </form>

        </div>
        <!-- END CARD BODY -->

    </div>
    <!-- END CARD -->

    <!-- CKEditor Scripts - Editor de texto-->
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace( 'description', {
            uiColor: '#9AB8F3',
        });
    </script>
    <!-- End CKEditor Scripts -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/especialidades/edit.blade.php ENDPATH**/ ?>