<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('images/victorino.png')); ?>" alt="" width="120px" height="70px">
        </a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
              <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(Página atual)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled" href="#">Desativado</a>
              </li>
            </ul>
          </div>
    </nav>
</div><?php /**PATH C:\Meus Projetos\victorino\resources\views/Site/Menu/MenuHome.blade.php ENDPATH**/ ?>