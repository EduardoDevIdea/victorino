
<div class="header">
    <nav class="menu">
        <ul class="menu_images">
            <li>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/Screenshot_2.png')); ?>" alt=""></a>
            </li>
        </ul>
        <ul class="menu_text">
            <li><a href="">Home</a>  </li>
            <li><a href="">Sobre Nós</a></li>
            <li><a href="">Especialidades</a></li>
            <li><a href="">Espaço</a></li>
            <li><a href="">Equipe Clinica</a></li>
            <li><a href="">Contatos</a></li>
            <li><a href="">Blog</a></li>
        </ul>
    </nav>
    <div class="menu_mobile">
        <i onclick="show_menu()" class="fas fa-bars fa-2x point_menu"></i>
        <ul id="menu_mobile" class="menu_text_mobile hide">
            <i onclick="hide_menu()" class="fas fa-times fa-2x point_menu close"></i>
            <li><a href="">Home</a>  </li>
            <li><a href="">Sobre Nós</a></li>
            <li><a href="">Especialidades</a></li>
            <li><a href="">Espaço</a></li>
            <li><a href="">Equipe Clinica</a></li>
            <li><a href="">Contatos</a></li>
            <li><a href="">Blog</a></li>
        </ul>
    </div>
</div>

<script>
    const menu = document.getElementById('menu_mobile');

    function show_menu() {
        menu.classList.remove('hide');
        menu.classList.add('show');
    }
    function hide_menu() {
        menu.classList.remove('show');
        menu.classList.add('hide');
    }

</script>

<style>

    a {
        text-decoration: none;
        color: white;
    }
    a:hover {
        color: #B06F1A;
    }
    ul {
        list-style: none;
        text-decoration: none;
    }
    .menu {
        background: #231F20;
        width: 100%;
        display: inline-flex;
    }
    .menu_images {
        width: 40%;
    }
    .menu_images img{
        display: inline-flex;
        justify-content: flex-start;
        width: 150px;
        height: 100px;
    }
    .menu_text {
        display: inline-flex;
        color: white;
        float: right;
        justify-content: flex-end;
        align-items: center;
    }
    .menu_text li {
        margin-right: 20px;
        letter-spacing: 1px;
    }

    .point_menu {
        display: none;
    }
    .close{
        float: right
    }
    
    .menu_mobile .menu_text_mobile {
       background: #231F20;
    }
    
    .hide {
        display: none;
        animation: slide_close 0.5s forwards;
        left: -100px;
        transition: ease-out 1s linear;
    }
  
    .show {
        display: block;
        position: absolute;
        top: 0;
        left: -100px;
        padding: 50px;
        animation: menu_open 0.5s forwards;
        color: white;
        z-index: 10000;
    }


    @keyframes  menu_open {
        100% { left: 0; }
    }

    @keyframes  slide_close {
        0 { left: -0; }
    }

    @media  screen and (max-width: 992px) {
        .menu_text {
            display: none;
        }
        .point_menu {
            display: block;
        }
        .menu_images {
            display: inline-flex;
            justify-content: center;
            width: 100%;
            padding: 0;
        }
        .point_menu {
            position: absolute;
            top: 25px;
            left: 25px;
            color: white;
        }
        .menu_mobile li {
            padding: 20px 0 20px 20px;
        }

    }
  
</style><?php /**PATH C:\Meus Projetos\victorino\resources\views/Site/header.blade.php ENDPATH**/ ?>