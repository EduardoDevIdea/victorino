<?php if(session('store')): ?>
    <script>
        Swal.fire({
        icon: 'success',
        title: "Postagem publicada com sucesso",
        showConfirmButton: false,
        })
    </script>
<?php endif; ?>

<?php if(session('update')): ?>
<script>
    Swal.fire({
    icon: 'success',
    title: "Postagem editada com sucesso",
    showConfirmButton: false,
    })
</script>
<?php endif; ?>

<?php if(session('delete')): ?>
    <script>
        window.alert("<?php echo e(session('delete')); ?>");
    </script>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
<style>
    .page-breadcrumb {
        padding: 0 0 50px 0;
    }
    .add_post {
        margin-bottom: 50px; 
    }
</style>

<div class="container">
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block" style="padding: 0">
                <h2 class="page-title">Publicações</h2>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Publicações</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <div class="no_post text-center" style="justify-content: center; align-itens:center">
        <?php if(count($posts) == 0): ?>
            <h3>Nenhuma publicação disponivel</h3>
            <a href="<?php echo e(route('post.create')); ?>">Clique aqui para criar uma primeira publicação!</a>
        <?php endif; ?>
    </div>
    <?php if($posts): ?>
    <div class="col-md-4" style="padding: 0">
        <a class="add_post btn btn-info" href="<?php echo e(route('post.create')); ?>">Nova Publicação</a>
    </div>
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 25rem">
                        <img src="/storage/<?php echo e($post->img); ?>" height="200px;">

                        <div class="card-body" style="overflow: hidden; overflow-y: scroll">
                            <h5 class="card-title"><h3><?php echo e($post->titulo); ?></h3></h5>
                            <p class="card-text"><?php echo e($post->subtitulo); ?></p>
                        </div>
                        <hr>
                        <div class="card-footer">
                            <a class="btn btn-secondary" href="<?php echo e(route('post.edit', ['post' => $post->id ])); ?>">Editar</a>
                            <a class="btn btn-danger"  onclick = "apagar(<?php echo e($post->id); ?>)" style="color:white">
                                Excluir
                            </a>
                        </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </div>
    <?php endif; ?>
    <?php echo e($posts->links()); ?>

   
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script>
       function apagar(id) {
            Swal.fire({
                title: "Deletar Profissional ?!",
                text: "Você não poderá reverter essa ação!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                cancelButtonText: "Cancelar",
                confirmButtonText: "Deletar"
            }).then(async (result) => {
                if (result.value) {
                    var url = "<?php echo e(url('/post')); ?>"
                    var  response = await fetch(url + `/${id}/delete`)
                    window.location.reload()
                    
                }
            })
           
        }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/posts/index.blade.php ENDPATH**/ ?>