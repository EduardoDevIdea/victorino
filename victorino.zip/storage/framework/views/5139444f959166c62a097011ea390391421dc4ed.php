<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center" style="padding: 0 0 50px 0">
            <h2 class="page-title">Dashboard</h2>
            <div class="ml-auto text-right">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <?php if( Auth::user()->type == "master" ||  Auth::user()->type == "admin"): ?>
    <div class="col-md-6 col-lg-2 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/user/list')); ?>">
                <div class="box bg-cyan text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-account-multiple-plus"></i></h1>
                    <h6 class="text-white">Usuarios</h6>
                </div>
            </a>
        </div>
    </div>
    <?php endif; ?>
    <!-- Column -->
    <div class="col-md-6 col-lg-4 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/sobre')); ?>">
                <div class="box bg-success text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-border-color"></i></h1>
                    <h6 class="text-white">Sobre nós</h6>
                </div>
            </a>
        </div>
    </div>
     <!-- Column -->
    <div class="col-md-6 col-lg-2 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('image')); ?>">
                <div class="box bg-warning text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-camera-enhance"></i></h1>
                    <h6 class="text-white">Imagens</h6>
                </div>
            </a>
        </div>
    </div>
    <!-- Column -->
    <div class="col-md-6 col-lg-2 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/especialidade')); ?>">
                <div class="box bg-danger text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-check-circle"></i></h1>
                    <h6 class="text-white">Especialidades</h6>
                </div>
            </a>
        </div>
    </div>
    <div class="col-md-6 col-lg-2 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/profissional')); ?>">
                <div class="box bg-info text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-account-box"></i></h1>
                    <h6 class="text-white">Profissionais</h6>
                </div>
            </a>
        </div>
    </div>
    <!-- Column -->
    <div class="col-md-6 col-lg-2 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/photo')); ?>">
                <div class="box bg-info text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-arrow-all"></i></h1>
                    <h6 class="text-white">O Espaço</h6>
                </div>
            </a>
        </div>
    </div>
    <!-- Column -->
    <!-- Column -->
    <div class="col-md-6 col-lg-4 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/post')); ?>">
                <div class="box bg-danger text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-receipt"></i></h1>
                    <h6 class="text-white">Blog</h6>
                </div>
            </a>
        </div>
    </div>
    <!-- Column -->
    <div class="col-md-6 col-lg-2 col-xlg-3">
        <div class="card card-hover">
            <a href="<?php echo e(url('/contact')); ?>">
                <div class="box bg-info text-center">
                    <h1 class="font-light text-white"><i class="mdi mdi-relative-scale"></i></h1>
                    <h6 class="text-white">Contato</h6>
                </div>
            </a>
        </div>
    </div>
   
</div>



<div class="row">

    <div class="col-lg-6">
    
        <div class="card" style="height: 100%">
            <div class="card-body">
                <h4 class="card-title">Ultimas postagens</h4>
            </div>
            <?php if(count($posts) == 0): ?>
                <div class="container">
                    <p>Nenhuma Postagem encontrada</p>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment-widgets scrollable">
                        <div class="d-flex flex-row comment-row m-t-0">
                            <div class="p-2"><img src="storage/<?php echo e($item_post->img); ?>" alt="user" width="50" class="rounded-circle"></div>
                            <div class="comment-text w-100">
                                <h6 class="font-medium"><?php echo e($item_post->titulo); ?></h6>
                                <span class="m-b-15 d-block"><?php echo e($item_post->subtitulo); ?> </span>
                                <div class="comment-footer">
                                    <span class="text-muted float-right"><?php echo e($item_post->created_at->format('M d , Y')); ?></span> 
                                    <a type="button" class="btn btn-cyan btn-sm" href="<?php echo e(route('post.edit', ['post' => $item_post->id ])); ?>">Editar</a>
                                    <a type="button" class="btn btn-danger btn-sm" href="<?php echo e(route('post.destroy', ['post' => $item_post->id])); ?>" onclick = "return confirm('Tem certeza que deseja excluir a publicação?');">Deletar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="row">
                <div class="col-4 offset-7">
                    <a href="<?php echo e(url('/post')); ?>" class="btn btn-info">clique aqui para mais postagens</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card" style="height: 100%">
            <div class="card-body">
                <h4 class="card-title">Profissionais</h4>
            </div>
            <div class="comment-widgets scrollable">
                <!-- Comment Row -->
                <?php if(count($profi) == 0): ?>
                    <div class="container">
                        <p>Nenhum Profissional cadastrado</p>
                    </div>
                <?php else: ?>
                    <?php $__currentLoopData = $profi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_profi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-row comment-row m-t-0">
                            <div class="p-2"><img src="storage/<?php echo e($item_profi->img); ?>" alt="user" width="50" class="rounded-circle"></div>
                            <div class="comment-text w-100">
                                <h6 class="font-medium"><?php echo e($item_profi->nome); ?></h6>
                                <span class="m-b-15 d-block"><?php echo $item_profi->sobre; ?> </span>
                                <div class="comment-footer">
                                    <button type="button" class="btn btn-cyan btn-sm">Edit</button>
                                    <button type="button" class="btn btn-danger btn-sm">Delete</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
               
            </div>
            <div class="row">
                <div class="col-4 offset-6">
                    <a href="<?php echo e(url('/profissional')); ?>" class="btn btn-info">clique aqui para ver todos os profissionais</a>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/home.blade.php ENDPATH**/ ?>