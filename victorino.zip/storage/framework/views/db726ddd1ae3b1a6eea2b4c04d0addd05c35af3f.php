<?php $__env->startSection('form'); ?>

    <?php echo $__env->make('images.banner.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Modal para Adicinar imagem -->

    <div class="container">

        <div class="row my-4">
            <h2>Banner</h2>
        </div>
        
        <!-- Botão dispara Modal -->
        <button type="button" class="btn btn-secondary mb-4" data-toggle="modal" data-target="#create">
            Adicionar imagem
        </button>
        <!-- Fim Botão dispara Modal -->

        <div>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="/storage/<?php echo e($image->path); ?>" class="m-1">
                <a href="<?php echo e(route('image.edit', ['image' => $image->id])); ?>" class="btn btn-warning">
                    Editar
                </a>
                <a href="<?php echo e(route('image.destroy', ['image' => $image->id ])); ?>" onclick="return confirm('Tem certeza que deseja excluir o banner?');">
                    Excluir
                </a>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if(count($images) === 0): ?>
            <h3>Nenhuma imagem adicionada, até o momento.</h3>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('images.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/banner/list.blade.php ENDPATH**/ ?>