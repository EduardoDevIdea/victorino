<?php if(session('store')): ?>
    <script>
        window.alert("<?php echo e(session('store')); ?>");
    </script>
<?php endif; ?>

<?php if(session('erroStore')): ?>
    <script>
        window.alert("<?php echo e(session('erroStore')); ?>");
    </script>
<?php endif; ?>

<?php if(session('update')): ?>
    <script>
        window.alert("<?php echo e(session('update')); ?>");
    </script>
<?php endif; ?>

<?php if(session('erroUpdate')): ?>
    <script>
        window.alert("<?php echo e(session('erroUpdate')); ?>");
    </script>
<?php endif; ?>

<?php if(session('destroy')): ?>
    <script>
        window.alert("<?php echo e(session('destroy')); ?>");
    </script>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Imagens</h2>
            <div class="ml-auto text-right">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item" aria-current="page">Imagens</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

    <div class="container">

        <h2 class="text-center">Atualize as imagens do site quando quiser.</h2>

        <div class="row w-auto mt-4 mb-5">

            <div class="col d-flex justify-content-center">
                <a class="btn btn-primary w-75" href="<?php echo e(route('image.list', ['image' => 'logo'])); ?>">Logomarca</a> 
            </div>

            <div class="col d-flex justify-content-center">
                <a class="btn btn-primary w-75" href="<?php echo e(route('image.list', ['image' => 'banner'])); ?>">Banner</a> 
            </div>

            <div class="col d-flex justify-content-center">
                <a class="btn btn-primary w-75" href="<?php echo e(route('image.list', ['image' => 'background'])); ?>">Background</a> 
            </div>

            <div class="col d-flex justify-content-center">
                <a class="btn btn-primary w-75" href="<?php echo e(route('image.list', ['image' => 'speciality'])); ?>">Especialidade</a> 
            </div>

        </div>
        
        <?php echo $__env->yieldContent('form'); ?>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/index.blade.php ENDPATH**/ ?>