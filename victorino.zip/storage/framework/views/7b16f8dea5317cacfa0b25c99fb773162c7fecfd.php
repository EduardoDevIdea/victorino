<?php $__env->startSection('content'); ?>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

    <?php if(session('store')): ?>
        <script>
            Swal.fire({
            icon: 'success',
            title: "<?php echo e(session('store')); ?>",
            showConfirmButton: false,
            })
        </script>
    <?php endif; ?>

    <?php if(session('update')): ?>
        <script>
            Swal.fire({
            icon: 'success',
            title: "<?php echo e(session('update')); ?>",
            showConfirmButton: false,
            })
        </script>
    <?php endif; ?>

    <?php if(session('erroImg')): ?>
        <script>
            Swal.fire({
            icon: 'danger',
            title: "<?php echo e(session('erroImg')); ?>",
            showConfirmButton: false,
            })
        </script>
    <?php endif; ?>


    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h2 class="page-title">Espaço</h2>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">Espaço</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <!-- CARD -->
    <div class="card text-center">

        <!-- CARD HEADER-->
        <div class="card-header" style="font-size: 20px">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="#"><strong>Galeria de fotos</strong></a>
                </li>
            </ul>
        </div>
        <!-- END CARD HEADER-->

        <!-- CARD BODY -->
        <div class="card-body m-2" style="font-size: 15px">

            <?php echo $__env->make('photos.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Modal para adicinar foto -->

            <!-- VERIFICAÇÃO - se limite de 8 fotos foi atingido, não aparece botão para adicionar foto -->
                <?php if($qtd < 8): ?> 

                    <div class="row">
                        <div class="col text-left">
                            <!-- BOTAO DISPARA MODAL --> <!-- Modal é o arquivo 'photos.create' -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create">
                                Nova Foto
                            </button>
                            <!-- FIM BOTAO -->
                            <span class="ml-2">Máximo: 8.</span>
                        </div>
                    </div>

                <?php else: ?>
                <h3>Limite de 8 fotos atingido. Altere a foto ou exclua para adicionar nova.</h3>
                <?php endif; ?>    
            <!--END VERIFICAÇÃO -->

            <!-- Div Fotos-->
            <div class="container mt-4">
        
                <div class="row my-5">

                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-3 ">

                            <div class="row">
                                <img src="/storage/<?php echo e($photo->path); ?>" style="width: 230px; height: 150px;">
                            </div>

                            <div class="row mb-5 d-flex justify-content-center align-items-center">

                                <?php echo $__env->make('photos.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Modal para alterar foto -->

                                <!-- BOTAO DISPARA MODAL --> <!-- Modal é o arquivo 'photos.create' -->
                                <a href="<?php echo e(route('photo.edit', ['photo' => $photo->id ])); ?>"  data-toggle="modal" data-target="#update<?php echo e($photo->id); ?>" class="btn btn-secondary btn-sm mr-3" title="Alterar foto">
                                    Alterar
                                </a>
                                <!-- FIM BOTAO -->
    
                                <button class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Excluir">
                                    <a  onclick="apagar(<?php echo e($photo->id); ?>)" >
                                        <i class="fas fa-trash-alt" style="color: red"></i> <!-- icone -->
                                    </a>
                                </button>
                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
    
            </div>
            <!-- Fim Div Fotos -->

        </div>
        <!-- END CARD BODY -->

    </div>
    <!-- END CARD -->

    <!-- sweetalert script -->
    <script>
        function apagar(id) {
                Swal.fire({
                    title: "Deletar Imagem ?!",
                    text: "Você não poderá reverter essa ação!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    cancelButtonText: "Cancelar",
                    confirmButtonText: "Deletar"
                }).then(async (result) => {
                    if (result.value) {
                    var url = "<?php echo e(url('/photo')); ?>"
                        var  response = await fetch(url + `/${id}/delete`)
                        window.location.reload()
                        
                    }
                })
            
            }
    </script>
    <!-- End sweetalert script-->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/photos/index.blade.php ENDPATH**/ ?>