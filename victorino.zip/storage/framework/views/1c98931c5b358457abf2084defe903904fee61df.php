<?php $__env->startSection('form'); ?>

    <div class="container">

        <div class="row my-4">
            <h2><strong>Background</strong></h2>
        </div>
        
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="row w-100 mb-4">
                <div class="col">
                    <img src="/storage/<?php echo e($image->path); ?>" style="width: 400px; height: 170;"> <br>
                </div>
                <div class="col d-flex align-items-center">
                    <a href="<?php echo e(route('image.edit', ['image' => $image->id ])); ?>" class="btn btn-warning">
                        Alterar
                    </a>
                </div>
            </div>
                        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('images.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/background/list.blade.php ENDPATH**/ ?>