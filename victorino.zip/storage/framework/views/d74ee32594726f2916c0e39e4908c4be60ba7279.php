<?php if(session('erros')): ?>
    <script>
        window.alert("<?php echo e(session('erros')); ?>");
    </script>
<?php endif; ?>

<?php $__env->startSection('form'); ?>

    <div class="container">

        <div class="row my-4">
            <h2><strong>Background</strong></h2>
        </div>
        
        <form action="<?php echo e(route('image.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="background" value="1">

            <div class="row mt-4 ">
                <div class="col-6">
                    <p><strong>Imagem 1</strong> <input type="file" name="bkg1"></p>
                
                    <p><strong>Imagem 2</strong> <input type="file" name="bkg2"></p>
                    
                    <p><strong>Imagem 3</strong> <input type="file" name="bkg3"></p>
                </div>
                <div class="col-6 border border-dark rounded">
                    *As imagens selecionadas serão exibidas como plano de fundo do site em suas respectivas posições
                    e aparecerão à medida que navegar verticalmente pelo site.
                </div>
            </div>
        
            <div class="row mt-1 w-50">
                <input type="submit" class="btn btn-success mx-auto" value="Atualizar" style="width: 30%;">
            </div>
        </form>
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('images.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/images/background/create.blade.php ENDPATH**/ ?>