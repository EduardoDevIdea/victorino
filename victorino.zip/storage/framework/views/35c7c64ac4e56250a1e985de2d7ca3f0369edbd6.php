<?php if(session('erroImg')): ?>
    <script>
        window.alert("<?php echo e(session('erroImg')); ?>");
    </script>
<?php endif; ?>


<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block" style="padding: 0">
            <h2 class="page-title">Editar Publicação</h2>
            <div class="ml-auto text-right">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url('/post')); ?>">Publicações</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Editar Publicação</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

    <div class="container mt-4">

        <form  action="<?php echo e(route('post.update', ['post' => $post->id ])); ?>"  method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>


            <div class="form-group">
                <label for="titulo">Título</label>
                <input type="text" name="titulo" id="titulo" class="form-control" value="<?php echo e($post->titulo); ?>">
            </div>

            <div class="form-group">
                <label for="subtitulo">Subtítulo</label>
                <input type="text" name="subtitulo" id="subtitulo" class="form-control" value="<?php echo e($post->subtitulo); ?>">
            </div>

            <div class="mb-4">
                <img src="/storage/<?php echo e($post->img); ?>" alt="" width="350px"><br><br>
                <p>
                    <a class="btn btn-info" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                     Alterar Foto
                    </a>
                  </p>
                  <div class="collapse" id="collapseExample">
                    <div class="card card-body">
                        <input type="file" name="img" id="img">
                    </div>
                  </div>
                
            </div>

            <div class="form-group">
                <label for="texto">Texto</label>
                <!-- Configuração de id e name para textarea de acordo com tutorial de instalação do Editor de texto (CKEditor) --> 
                <textarea class="form-control" id="texto" name="texto"><?php echo $post->texto; ?> </textarea>
            </div>

            <input type="submit" value="Atualizar" class="btn btn-primary">
                             
        </form>

    </div>

    </div>
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace( 'texto', {
            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form',
            uiColor: '#9AB8F3',
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/posts/edit.blade.php ENDPATH**/ ?>