<?php if(session('erroImg')): ?>
    <script>
        window.alert("<?php echo e(session('erroImg')); ?>");
    </script>
<?php endif; ?>


<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block" style="padding: 0">
            <h2 class="page-title">Nova publicação</h2>
            <div class="ml-auto text-right">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url('/post')); ?>">Publicações</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Nova Publicação</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>


    <div class="container mt-4">

        <form action="<?php echo e(route('post.store')); ?>"  method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="titulo">Título</label>
                <input type="text" name="titulo" id="titulo" class="form-control">
            </div>

            <div class="form-group">
                <label for="subtitulo">Subtítulo</label>
                <input type="text" name="subtitulo" id="subtitulo" class="form-control">
            </div>

            <div class="mb-4">
                <label for="img">Imagem<small style="color: red;"> *Imagem principal</small></label> <br>
                <input type="file" name="img" id="img">
            </div>

            <div class="form-group">
                <label for="texto">Texto</label>
                <!-- Configuração de id e name para textarea de acordo com tutorial de instalação do Editor de texto (CKEditor) --> 
                <textarea class="form-control" id="texto" name="texto"></textarea>
            </div>

            <input type="submit" value="Publicar" class="btn btn-primary">
                             
        </form>

    </div>

    <!-- Script para rodar o editor de texto CKEditor -->
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace( 'texto', {
            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form',
            uiColor: '#9AB8F3',
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Meus Projetos\victorino\resources\views/posts/create.blade.php ENDPATH**/ ?>